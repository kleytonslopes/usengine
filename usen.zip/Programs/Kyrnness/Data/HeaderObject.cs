﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kyrnness.Data
{
    public class HeaderObject
    {
        public bool HasPragmaOnce { get; set; }
    }
}
