﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassCreator.Data
{
    public class ClassRegister
    {
        public string ClassName { get; set; }
        public ClassData Data { get; set; }
    }
}
